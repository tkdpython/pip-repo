"""
`plotly_express` is now an alias for `plotly.express`
"""

__version__ = "0.4.1"  # sync with setup.py!

from plotly.express import *
