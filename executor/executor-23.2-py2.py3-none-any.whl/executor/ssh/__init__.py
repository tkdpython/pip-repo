"""This module groups the :mod:`executor.ssh.client` and :mod:`executor.ssh.server` functionality."""
