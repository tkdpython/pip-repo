"""ntc_templates - Parse raw output from network devices and return structured data."""

__version__ = "2.0.0"
