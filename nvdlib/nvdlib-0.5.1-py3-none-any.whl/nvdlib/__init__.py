from .cve import getCVE, searchCVE
from .cpe import searchCPE