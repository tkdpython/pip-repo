from __future__ import unicode_literals
from netmiko.yamaha.yamaha import YamahaSSH, YamahaTelnet

__all__ = ["YamahaSSH", "YamahaTelnet"]
