from netmiko import ConnectHandler  # noqa


def test_placeholder():
    assert True
